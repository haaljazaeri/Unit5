import UIKit
import Parse

class SignUpViewController: UIViewController {
    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        if let email = emailField.text, !email.isEmpty, let passText = passField.text, !passText.isEmpty, let userName = userNameField.text, !userName.isEmpty {
            SignUp (userName: userName , pass: passText, userEmail: email)
        } else {
            self.displayAlert(withTitle: "Alert", message: "Please fill the required data")
        }
    }
    
    func SignUp(userName: String, pass: String, userEmail: String) {
        var user = User()
        user.username = userName
        user.password = pass
        user.email = userEmail
        
        user.signup { result in
            
            switch result {
            case .success( _):
                self.navigationController?.popViewController(animated: true)
                self.displayAlert(withTitle: "Success", message: "Account has been successfully created")
            case .failure(let error):
                // Failed sign up
                self.displayAlert(withTitle: "Error", message: error.localizedDescription)
            }
        }
    }
}
