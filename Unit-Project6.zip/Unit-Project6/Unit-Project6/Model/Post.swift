import Foundation
import Parse
import ParseSwift

struct Post: ParseObject {
    
    var objectId: String?
    // These are required by ParseObject var objectId: String?
    var createdAt: Date?
    var updatedAt: Date?
    var ACL: ParseACL?
    var originalData: Data?
    var user: User?
    // Your own custom properties.
    var caption: String?
    var imageFile: ParseFile?
}
