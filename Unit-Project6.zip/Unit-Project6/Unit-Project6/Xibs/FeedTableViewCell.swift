import UIKit
import Alamofire
import AlamofireImage


class FeedTableViewCell: UITableViewCell {
    
    @IBOutlet weak var captionLbl: UILabel!
    @IBOutlet weak var createdLbl: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var feedImage: UIImageView!
    
    @IBOutlet weak var blurView: UIView!
    var post: Post? {
        didSet {
            if let post = post {
                populateData(post: post)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        feedImage.layer.cornerRadius = 8
    }
    
    func populateData(post: Post) {
        if let imageFile = post.imageFile, let imageUrl = imageFile.url {
            AF.request(imageUrl).responseImage { [weak self] response in
                switch response.result {
                case .success(let image):
                    self?.feedImage.image = image
                    if let currentUser = User.current,
                       let lastPostedDate = currentUser.lastPostedDate, // Get the date the given post was created.
                       let postCreatedDate = post.createdAt {
                        let diffHours = Calendar.current.dateComponents([.hour], from: postCreatedDate, to: lastPostedDate)
                        // Hide the blur view if the given post was created within 24 hours of the current use
                        if diffHours.hour! < 24 {
                            self?.blurView.isHidden = true
                        }
                    } else {
                        self?.blurView.isHidden = false
                        
                    }
                case .failure(let error):
                    print(" Error fetching image: \(error.localizedDescription)")
                    break
                }
            }
        }
        
        userName.text = post.user?.username
        createdLbl.text = String(describing: post.createdAt!)
        captionLbl.text = post.caption
    }
}

