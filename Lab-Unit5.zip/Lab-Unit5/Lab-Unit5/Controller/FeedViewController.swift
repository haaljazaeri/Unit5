import UIKit

class FeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var feedTableView: UITableView!
    
    var posts: [Post] = [] {
        didSet {
            if posts.count > 0 {
                DispatchQueue.main.async {
                    self.feedTableView.reloadData()
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        feedTableView.register(FeedTableViewCell.self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getPosts()
    }
    
    private func getPosts() {
        let query = Post.query()
            .include("user") .order([.descending("createdAt")])
        // Fetch objects (posts) defined in query (async)
        query.find { [weak self] result in
            switch result {
            case .success(let posts):
                print(posts.count)
                self?.posts = posts
            case .failure(let error):
                self?.displayAlert(withTitle: "Error", message: error.localizedDescription)
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let feedCell = feedTableView.dequeueReusableCell(withIdentifier: FeedTableViewCell.identifier, for: indexPath) as? FeedTableViewCell {
            feedCell.post = posts[indexPath.row]
            return feedCell
        }
        return UITableViewCell()
    }
    
    
    @IBAction func logoutAction(_ sender: Any) {
        User.logout { [weak self] result in
            switch result {
            case .success:
                DispatchQueue.main.async {
                    self?.navigationController?.popToRootViewController(animated: true)
                }
            case .failure(let error):
                print(" Log out error: \(error)")
            }
        }
    }
}
