import UIKit
import ParseSwift
import PhotosUI

class PostViewController: UIViewController, PHPickerViewControllerDelegate {
    
    @IBOutlet weak var postButton: UIButton!
    @IBOutlet weak var captionView: UITextView!
    @IBOutlet weak var postImageView: UIImageView!
    var post = Post()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postImageView.isHidden = true
        captionView.isHidden = true
        postButton.isHidden = true
        captionView.layer.borderWidth = 1
        captionView.layer.borderColor = UIColor.black.cgColor
    }
    
    @IBAction func selectPhoto(_ sender: Any) {
        configure()
    }
    
    private func configure() {
        
        var configuration = PHPickerConfiguration ()
        configuration.filter = .images
        configuration.selectionLimit = 1
        
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        self.present(picker, animated: true)
    }
    
    
    @IBAction func showFeedAction(_ sender: Any) {
        if let feedVC = self.storyboard?.instantiateViewController(withIdentifier: "FeedViewController") as? FeedViewController {
            self.navigationController?.pushViewController(feedVC, animated: true)
        }
        
    }
    
    @IBAction func postAction(_ sender: Any) {
        post.caption = captionView.text
        self.post.save { result in
            // Switch to the main thread for any UI updates
            DispatchQueue.main.async {
                switch result {
                case .success(let post):
                    print(" Post Saved! \(post)")
                    self.displayAlert(withTitle: "Uploaded", message: "Post Successfully")
                    self.postImageView.isHidden = true
                    self.captionView.isHidden = true
                    self.postButton.isHidden = true
                case .failure(let error):
                    print(" Post failed! \(error.localizedDescription)")
                }
            }
        }
    }
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        
        let itemProviders = results.map(\.itemProvider)
        for (_, itemProvider) in itemProviders.enumerated() where itemProvider.canLoadObject(ofClass: UIImage.self) {
            
            itemProvider.loadObject(ofClass: UIImage.self) {[weak self] (image, error) in
                DispatchQueue.main.async { [self] in
                    guard let self = self, let image = image as? UIImage else { return }
                    self.postImageView.image = image
                    let imageData = image.jpegData(compressionQuality: 0.5)
                    let imageFile = ParseFile(name: "image.jpg", data: imageData!)
                    var post = Post()
                    self.postImageView.isHidden = false
                    self.captionView.isHidden = false
                    self.postButton.isHidden = false
                    
                    post.imageFile = imageFile
                    post.user = User.current
                    
                    self.post = post
                }
            }
        }
    }
}
