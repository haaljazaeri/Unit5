import UIKit
import Parse

class ViewController: UIViewController {
    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if User.current != nil {
            if let postVC = self.storyboard?.instantiateViewController(withIdentifier: "PostViewController") as? PostViewController {
                self.navigationController?.pushViewController(postVC, animated: true)
            }
        }
    }
    
    
    @IBAction func loginAction(_ sender: Any) {
        if let userName = emailField.text, !userName.isEmpty, let passText = passField.text, !passText.isEmpty {
            SignIn (userName: userName , pass: passText)
        } else {
            self.displayAlert(withTitle: "Alert", message: "Please fill the required data")
        }
        
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        if let signUp = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as? SignUpViewController {
            self.navigationController?.pushViewController(signUp, animated: true)
        }
    }
    
    private func SignIn(userName: String, pass: String) {
        
        User.login(username: userName, password: pass) { [weak self] result in
            switch result {
            case .success( _):
                if let postVC = self?.storyboard?.instantiateViewController(withIdentifier: "PostViewController") as? PostViewController {
                    self?.emailField.text = " "
                    self?.passField.text = " "
                    self?.navigationController?.pushViewController(postVC, animated: true)
                }
            case .failure(let error):
                self?.displayAlert(withTitle: "Error", message: error.localizedDescription)
            }
        }
    }
}


