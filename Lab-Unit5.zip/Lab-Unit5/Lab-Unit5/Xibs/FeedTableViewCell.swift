import UIKit
import Alamofire
import AlamofireImage


class FeedTableViewCell: UITableViewCell {
    
    @IBOutlet weak var captionLbl: UILabel!
    @IBOutlet weak var createdLbl: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var feedImage: UIImageView!
    
    var post: Post? {
        didSet {
            if let post = post {
                populateData(post: post)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        feedImage.layer.cornerRadius = 8
    }
    
    func populateData(post: Post) {
        if let imageFile = post.imageFile, let imageUrl = imageFile.url {
            AF.request(imageUrl).responseImage { [weak self] response in
                switch response.result {
                case .success(let image):
                    self?.feedImage.image = image
                case .failure(let error):
                    print(" Error fetching image: \(error.localizedDescription)")
                    break
                } }
        }
        
        userName.text = post.user?.username
        createdLbl.text = String(describing: post.createdAt!)
        captionLbl.text = post.caption
    }
    
}
