import UIKit
import ParseSwift
import PhotosUI

class PostViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var postButton: UIButton!
    @IBOutlet weak var captionView: UITextView!
    @IBOutlet weak var postImageView: UIImageView!
    var post = Post()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postImageView.isHidden = true
        captionView.isHidden = true
        postButton.isHidden = true
        captionView.layer.borderWidth = 1
        captionView.layer.borderColor = UIColor.black.cgColor
    }
    
    @IBAction func selectPhoto(_ sender: Any) {
        configure()
    }
    
    private func configure() {
        
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print(" Camera not available")
            return
        }
        
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .camera
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        present(imagePicker, animated: true)
    }
    
    
    @IBAction func showFeedAction(_ sender: Any) {
        if let feedVC = self.storyboard?.instantiateViewController(withIdentifier: "FeedViewController") as? FeedViewController {
            self.navigationController?.pushViewController(feedVC, animated: true)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.editedImage] as? UIImage else {
            print(" Unable to get image")
            return
        }
        
        self.postImageView.image = image
        let imageData = image.jpegData(compressionQuality: 0.5)
        let imageFile = ParseFile(name: "image.jpg", data: imageData!)
        var post = Post()
        self.postImageView.isHidden = false
        self.captionView.isHidden = false
        self.postButton.isHidden = false
        
        post.imageFile = imageFile
        post.user = User.current
        
        self.post = post
    }
    
    @IBAction func postAction(_ sender: Any) {
        post.caption = captionView.text
        self.post.save { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let post):
                    print(" Post Saved! \(post)")
                    self.displayAlert(withTitle: "Uploaded", message: "Post Successfully")
                    self.postImageView.isHidden = true
                    self.captionView.isHidden = true
                    self.postButton.isHidden = true
                case .failure(let error):
                    print(" Post failed! \(error.localizedDescription)")
                }
            }
        }
        
        updateLastDateTime()
    }
    
    private func updateLastDateTime() {
        
        if var currentUser = User.current {
            let yesterdayDate = Calendar.current.date(byAdding: .day, value: (-1), to: Date())!
            currentUser.lastPostedDate = yesterdayDate
            currentUser.save { [weak self] result in
                switch result {
                case .success(let user):
                    print("✅ User Saved! \(user)")
                case .failure(let error):
                    self?.displayAlert(withTitle: "", message: error.localizedDescription)
                }
            }
        }
    }
}
