import ParseSwift
import Foundation

struct User: ParseUser {
    
    var originalData: Data?
    
    var createdAt: Date?
    
    var updatedAt: Date?
    
    var objectId: String?
    
    var ACL: ParseACL?
    
    var username: String?
    
    var email: String?
    
    var emailVerified: Bool?
    
    var password: String?
    
    var authData: [String: [String: String]?]?
    
    var lastPostedDate: Date?
}

