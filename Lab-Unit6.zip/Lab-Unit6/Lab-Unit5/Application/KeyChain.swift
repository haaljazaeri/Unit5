//
//  KeyChain.swift
//  Lab-Unit5
//
//  Created by Zain@10Pearls on 25/04/2023.
//

import Foundation
import ParseSwift

class KeyChain: ParseKeyValueStore {
    
    func delete(valueFor key: String) throws {
         
    }
    
    func deleteAll() throws {
         
    }
    
    func get<T>(valueFor key: String) throws -> T? where T : Decodable {
        return nil
    }
    
    func set<T>(_ object: T, for key: String) throws where T : Encodable {
         
    }
 }
